import Cocoa

//public class LLNode<T> {
//    var value:T
//    var next:LLNode?
//    var prev:LLNode?
//
//    public init(value:T) {
//        self.value = value
//    }
//
//}
//public class LinkedList<T> {
//    public typealias Node = LLNode<T>
//    private var head:Node?
//    public var first:Node? {
//        return head
//    }
//    public var last: Node? {
//        guard  var node = head else {
//            return nil
//        }
//        while let next = node.next {
//            node = next
//        }
//        return node
//    }
//    public var count: Int {
//        guard var node = head else {
//            return 0
//        }
//        var count = 1
//        while let next = node.next {
//            node = next
//            count += 1
//        }
//        return count
//    }
//
//    public var print: String {
//        var ListPrinted = "["
//        guard var node = head else {
//            return "[]"
//        }
//        while let next = node.next {
//            ListPrinted += "\(node.value), "
//            node = next
//        }
//        ListPrinted += "\(node.value) "
//        return ListPrinted + "]"
//    }
//
//    public func append(value:T) {
//        let newNode = Node(value: value)
//        if let lastNode = last {
//            newNode.prev = lastNode
//            lastNode.next = newNode
//        } else {
//           head = newNode
//        }
//    }
//
//    public func node(atIndex index :Int )-> Node {
//        if index == 0 {
//            return head!
//        } else {
//            var node = head?.next
//            for _ in 1..<index {
//                node = node?.next
//                if node  == nil {break}
//
//            }
//            return node!
//        }
//    }
//
//    public func insert(value: T, atIndex index:Int) {
//        let newNode = Node(value: value)
//        if index == 0 {
//            newNode.next = head
//            head?.prev = newNode
//            head = newNode
//        } else {
//            let prev = node(atIndex: index)
//            let next = prev.next
//            newNode.prev = prev
//            newNode.next = next
//            prev.next = newNode
//            next?.prev = newNode
//        }
//
//    }
//    public func remove(node:inout Node) ->T {
//        let prev = node.prev
//        let next = node.next
////        if let prev = prev {
////            prev.next = next
////        } else {
////            head = next
////        }
//        prev?.next = next
//        next?.prev = prev
//        node.prev = nil
//        node.next = nil
//        return node.value
//    }
//
//    public func removeAt(index:Int) -> T{
//        var nodeToRemove = node(atIndex: index)
//        return remove(node: &nodeToRemove)
//    }
//
//}
//
//
//
//
//let list = LinkedList<Int>()
//list.first
//list.last
//list.append(value: 1)
//list.append(value: 4)
//list.append(value: 3)
//list.append(value: 5)
//list.append(value: 6)
//list.count
//list.insert(value: 34, atIndex: 0)
//
//list.print
//list.node(atIndex: 2).value
//list.removeAt(index: 3)
//list.print

//public class ListNode {
//     public var val: Int
//     public var next: ListNode?
//     public init(_ val: Int) {
//         self.val = val
//         self.next = nil
//     }
// }
//func deleteDuplicates(_ head: ListNode?) -> ListNode? {
//   var curr:ListNode? = head
//    while (curr != nil && curr?.next != nil){
//        if curr?.next?.val == curr?.val {
//            curr?.next = curr?.next!.next
//    } else {
//        curr = curr?.next
//    }
//}
//return head!
//
//}
//
//func removeElements(_ head: ListNode?, _ val: Int) -> ListNode? {
//    var curr:ListNode? = head
//    if head != nil && head?.val == val
//    {return removeElements(head?.next, val)}
//    while curr != nil {
//        if curr?.next != nil && curr?.next!.val == val {
//            curr?.next = curr?.next?.next
//        } else {
//            curr = curr?.next
//        }
//
//    }
//    return head
//
//}
//ListNode curr = head;
//
//if(head != null && head.val == val)
//    return removeElements(head.next, val);
//
//while(curr != null)
//{
//    if(curr.next != null && curr.next.val == val)
//        curr.next = curr.next.next;
//    else
//        curr = curr.next;
//}
//
//return head;
//public int longestUnivaluePath(TreeNode root) {
//    ans = 0;
//    arrowLength(root);
//    return ans;
//}

//public class TreeNode {
//     public var val: Int
//     public var left: TreeNode?
//     public var right: TreeNode?
//     public init(_ val: Int) {
//         self.val = val
//         self.left = nil
//         self.right = nil    }
// }
//public int arrowLength(TreeNode node) {
//    if (node == null) return 0;
//    int left = arrowLength(node.left)
//    int right = arrowLength(node.right);
//    int arrowLeft = 0, arrowRight = 0;
//    if (node.left != null && node.left.val == node.val) {
//        arrowLeft += left + 1;
//    }
//    if (node.right != null && node.right.val == node.val) {
//        arrowRight += right + 1;
//    }
//    ans = Math.max(ans, arrowLeft + arrowRight);
//    return Math.max(arrowLeft, arrowRight);
//}
//var ans:Int = 0
//func longestUnivaluePath(_ root: TreeNode?) -> Int {
//    ans = 0
//    arrowLength(root)
//    return ans
//
//}
//
//func arrowLength(_ node:TreeNode?) -> Int{
//    if (node == nil) {return 0}
//    let left:Int = arrowLength(node?.left)
//    let right:Int = arrowLength(node?.right)
//    var arrowLeft:Int = 0
//    var arrowRight:Int = 0
//    if (node?.left != nil && node?.left?.val == node?.val) {
//            arrowLeft += left + 1;
//        }
//        if (node?.right != nil && node?.right?.val == node?.val) {
//            arrowRight += right + 1;
//        }
//        ans = max(ans, arrowLeft + arrowRight);
//        return max(arrowLeft, arrowRight);
//}
//
func reverse(str:String) -> String {
    let arr:[Character] = Array(str)
    return String(arr.reversed())
}
reverse(str: "sdsjkfsdbsdbfsdfnf")

//func reverseString(_ s: inout [Character]) {
//    var empty:[Character] = []
//    s.forEach { (Char) in
//        empty = empty + s.reversed()
//    }
//
//}

func reverse(_ x: Int) -> Int {
    if x > Int32.max || x < Int32.min {return 0}
    let isNegative:Bool = x < 0
    let signed:Int = Int(x * (isNegative ? -1 : 1))
    guard let reversed = Int(String(Array(String(signed).reversed())))
        else {return 0}
    let judge:Int = reversed * (isNegative ? -1 : 1)
    if judge > Int32.max || judge < Int32.min{
        return 0
    }else {
        return Int(judge)
    }
    
}
reverse(-21474)


//func isHappy(_ n: Int) -> Bool {
//    let sum:Int? = 0
//    
//    check(n)
//    if sum == 1{
//            return true
//        } else {
//            return false
//        }
//    }
func isHappy( _ n:Int)->Bool {
    let charmap = [Character:Int]()
    var sum:Int = 0
    var res:Bool = true
    let str:String = String(n)
    str.forEach { (char) in
        if charmap[char] != nil{
        sum =  charmap[char]! ^ 2

        } else {
            sum = 0
        }
    }
    while sum != 1 {
        res =  isHappy(sum)
    }
        if res == true {
            return true
        } else {

            return false
        }
}

isHappy(2)
isHappy(19)

func fizzBuzz(_ n: Int) -> [String] {
    var arr:[String] = [" "]
    for i in 1...n {
        if ( i % 3 == 0 && i % 5 == 0){
            print (arr.append("FizzBuzz"))
        } else if i % 3 == 0 {
           print (arr.append("Fizz"))
        } else if i % 5 == 0 {
          print (arr.append("Buzz"))
        }else {
            print(arr.append(String(n)))
        }
    }
    return [String(n)]
}
fizzBuzz(10)

