import Cocoa


func chunk( array:[Int], size:Int) -> [Any]{
    if size > array.count {
        return ["size is bigger than the size of the array"]
    }
    var restArray = [[Int]]()
    for i in size..<array.count {
         restArray += [[array[i]]]
    }
    let newArray = [array[..<size]] + restArray
  return newArray
}

//Testcases:

chunk(array: [1,2,4,3,4,3,4], size: 9 )
chunk(array: [1,2,4,3,4,3,4], size: 3 )
chunk(array: [0], size: 0)
