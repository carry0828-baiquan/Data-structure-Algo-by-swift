import Cocoa

var str = "Hello, playground"
func pal(str:String) -> Bool{
    var reverseStr = " "
    for character in str {
        
        reverseStr = String(character) + reverseStr
        
    }
    print(reverseStr)
    if (reverseStr == str) {
        return true
    } else {
        return false
    }
}
pal(str: "s")
pal(str: "as")
pal(str: "3232323")


