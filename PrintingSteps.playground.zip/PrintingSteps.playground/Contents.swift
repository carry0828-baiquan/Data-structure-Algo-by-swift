import Cocoa
func steps(n:Int, row:Int = 0, stair:String = "") {
    if (n == row) {
        return
      }

    if (n == stair.count) {
        print(stair)
        return steps(n: n, row: row + 1)
      }

      let  add = stair.count <= row ? "#": " "
    steps(n: n, row: row, stair: stair + add)
    }

steps(n:4)
 
print("     Solution 2 (recommend)             ")


func step(n:Int) {
    for row in 0..<n{
        var stair = ""
        for col in 0..<n{
            if (col <= row) {
                stair += "#"
            } else {
                stair += ""
            }
        }
        print(stair);
    }
}

step(n: 6)
