import Cocoa
//func anagrams ( A:String , B:String) -> Bool {
//    let aCharMap = buildcharMap(str: A)
//    let bCharMap = buildcharMap(str: B)
//    if aCharMap.keys.count != bCharMap.keys.count {
//        return false
//    }
//    for char in aCharMap.keys {
//        if aCharMap[char] != bCharMap[char] {
//            return false
//        }
//    }
//    return true
//}


//func buildcharMap(str:String) -> [Character:Int] {
//    var charMap = [Character:Int]()
//    let replaced = str.filter($0.isLetter)
//    for char in replaced{
//
//        charMap[char]  +=  1
//    }
//    return charMap
//}
//
//max  =
//anagrams(A: "lalaland", B: " lalaland")

//func maxChunksToSorted(_ arr: [Int]) -> Int {
//    var ans:Int = 0
//    var Max:Int = 0
//    for i in 0..<arr.count {
//        Max = max(Max, arr[i])
//        if (Max == i) {ans += 1}
//    }
//    return ans
//}
//maxChunksToSorted([1,2,3,4])
//func countPrimes(_ n: Int) -> Int {
//    var prime:[Int:Bool] = [n: true]
//    var cnt:Int = 0;
//    for i in 2..<n{
//    if (prime[i] != nil){
//            cnt += 1
//            for j in 2..<n{
//                if j * i < n{
//                    prime[j * i] = false}
//            }
//       } else {return 0}
//    }
//    return cnt;
//        }
        
func Compute(n: Int) -> Int {
    var N:Int = n
    var result:Int = 0
    while N>0{
        result += (N%10)^2
        N = Int(N/10)
    }
    return result
}
func isHappy(n: Int) -> Bool {
    var N:Int = n
    for _ in 0...n{
       let  s = Compute(n: N)
        if s == 1{
            return true}
        N = s
    }
    return false
}
isHappy(n: 19)
    

