import Cocoa

func maxChar(str:String){
    var charmap = [Character:Int]()
    var max:Int = 0
    var charmax:Character = "0"
    str.forEach { (char) in
        if (charmap[char] != nil) {
            charmap[char]! += 1
        }else{
            charmap[char] = 1
        }
    }
    charmap.forEach { (arg0) in
        let (char, val) = arg0
        if charmap[char]! > max {
            max = val
            charmax = char
        }
    }
   print("The char which appeared most often is " + "\(charmax)")
    print("It appeared \(max) times")
}
maxChar(str: "aaccsd")

