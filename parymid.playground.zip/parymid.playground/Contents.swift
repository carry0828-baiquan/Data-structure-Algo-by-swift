import Cocoa
func pyramid(n:Int) {
    for row in 0...n {
        var stair = ""
        for col in 0...(n-1)/2-1 {
            stair += ""
        }
        if col == (n-1)/2 {
            stair += "#"
        }
    }
}
