import Cocoa

func capitalize(str:String) -> String {
    var empty = [String]()
    for word in str.split(separator: " ") {
        empty.append(word[word.startIndex].uppercased() + word[word.index(after: word.startIndex)...])
    }
    return empty.joined(separator: " ")
}
//test
capitalize(str: "sdsd sdsd sd")
