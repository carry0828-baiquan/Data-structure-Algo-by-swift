import Cocoa

func reversInt(i:Int) -> Int?{
    var reverseStr = ""
    if i >= 0 {
        for char in String(i) {
            reverseStr = String(char) + reverseStr
            return (Int(reverseStr) ?? 0)
        }
        print(reverseStr)
    }else {
        for char in String(i * -1) {
            reverseStr = String(char) + reverseStr
        }
     return ( Int(reverseStr)!  * (-1))
    }
    return i
}
reversInt(i: 0)
